const express = require('express');
const session = require('express-session');
const SQLiteStoreFactory = require('connect-sqlite3');
const bcrypt = require('bcryptjs');
const Database = require('better-sqlite3');
const path = require('path');

const app = express();
const db = new Database(process.env.DB_PATH || path.join(__dirname, 'giftzone.sqlite'));
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS cart_items (user_id INTEGER NOT NULL, product_id TEXT NOT NULL, quantity INTEGER NOT NULL CHECK(quantity > 0), PRIMARY KEY(user_id, product_id));
CREATE TABLE IF NOT EXISTS orders (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, total INTEGER NOT NULL, status TEXT NOT NULL, items_json TEXT NOT NULL, created_at TEXT NOT NULL);
`);
const products = {'google-play-20': {id:'google-play-20', name:'Google Play Gift Card — $20', price:4900000}};
const SQLiteStore = SQLiteStoreFactory(session);
app.disable('x-powered-by');
app.use(express.json({limit:'20kb'}));
app.use(session({
  store: new SQLiteStore({db:'sessions.sqlite', dir:__dirname}),
  secret: process.env.SESSION_SECRET || 'CHANGE_THIS_TO_A_LONG_RANDOM_SECRET_BEFORE_DEPLOYING',
  resave:false, saveUninitialized:false,
  cookie:{httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production',maxAge:7*24*60*60*1000}
}));
app.use(express.static(path.join(__dirname,'public')));
const emailOk = s => typeof s==='string' && s.length<=254 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s);
const userById = id => db.prepare('SELECT id,email FROM users WHERE id=?').get(id);
function requireAuth(req,res,next){if(!req.session.userId)return res.status(401).json({error:'ابتدا وارد حساب کاربری شو.'});next()}
function cartFor(uid){return db.prepare('SELECT product_id,quantity FROM cart_items WHERE user_id=?').all(uid).map(r=>({...products[r.product_id],quantity:r.quantity,productId:r.product_id,subtotal:products[r.product_id].price*r.quantity}))}
app.post('/api/register', async (req,res)=>{
  const email=String(req.body.email||'').trim().toLowerCase(), password=String(req.body.password||'');
  if(!emailOk(email)||password.length<8||password.length>128)return res.status(400).json({error:'ایمیل معتبر و رمز عبور ۸ تا ۱۲۸ کاراکتری وارد کن.'});
  try{const hash=await bcrypt.hash(password,12);const result=db.prepare('INSERT INTO users(email,password_hash,created_at) VALUES(?,?,?)').run(email,hash,new Date().toISOString());req.session.userId=result.lastInsertRowid;res.json({ok:true})}
  catch(e){if(String(e.code).includes('CONSTRAINT'))return res.status(409).json({error:'این ایمیل قبلاً ثبت شده است.'});res.status(500).json({error:'ثبت‌نام انجام نشد.'})}
});
app.post('/api/login',async(req,res)=>{
  const email=String(req.body.email||'').trim().toLowerCase(), password=String(req.body.password||'');
  const u=db.prepare('SELECT * FROM users WHERE email=?').get(email);
  if(!u||!(await bcrypt.compare(password,u.password_hash)))return res.status(401).json({error:'ایمیل یا رمز عبور نادرست است.'});
  req.session.regenerate(err=>{if(err)return res.status(500).json({error:'ورود انجام نشد.'});req.session.userId=u.id;res.json({ok:true})});
});
app.post('/api/logout',(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get('/api/me',(req,res)=>res.json({user:req.session.userId?userById(req.session.userId):null}));
app.get('/api/cart',requireAuth,(req,res)=>{const items=cartFor(req.session.userId);res.json({items,total:items.reduce((s,x)=>s+x.subtotal,0)})});
app.post('/api/cart',requireAuth,(req,res)=>{
  const p=products[req.body.productId], q=Number(req.body.quantity||1);
  if(!p||!Number.isInteger(q)||q<1||q>20)return res.status(400).json({error:'محصول یا تعداد معتبر نیست.'});
  db.prepare(`INSERT INTO cart_items(user_id,product_id,quantity) VALUES(?,?,?) ON CONFLICT(user_id,product_id) DO UPDATE SET quantity=MIN(quantity+excluded.quantity,20)`).run(req.session.userId,p.id,q);
  res.json({ok:true});
});
app.patch('/api/cart',requireAuth,(req,res)=>{
  const p=products[req.body.productId],q=Number(req.body.quantity);
  if(!p||!Number.isInteger(q)||q<0||q>20)return res.status(400).json({error:'تعداد معتبر نیست.'});
  if(q===0)db.prepare('DELETE FROM cart_items WHERE user_id=? AND product_id=?').run(req.session.userId,p.id);
  else db.prepare('INSERT INTO cart_items(user_id,product_id,quantity) VALUES(?,?,?) ON CONFLICT(user_id,product_id) DO UPDATE SET quantity=excluded.quantity').run(req.session.userId,p.id,q);
  res.json({ok:true});
});
app.delete('/api/cart/:id',requireAuth,(req,res)=>{db.prepare('DELETE FROM cart_items WHERE user_id=? AND product_id=?').run(req.session.userId,req.params.id);res.json({ok:true})});
app.post('/api/orders',requireAuth,(req,res)=>{
  const uid=req.session.userId,items=cartFor(uid);
  if(!items.length)return res.status(400).json({error:'سبد خرید خالی است.'});
  const total=items.reduce((s,x)=>s+x.subtotal,0);
  const result=db.prepare('INSERT INTO orders(user_id,total,status,items_json,created_at) VALUES(?,?,?,?,?)').run(uid,total,'در انتظار پرداخت',JSON.stringify(items.map(x=>({productId:x.productId,name:x.name,price:x.price,quantity:x.quantity}))),new Date().toISOString());
  db.prepare('DELETE FROM cart_items WHERE user_id=?').run(uid);
  res.json({ok:true,orderId:result.lastInsertRowid,status:'در انتظار پرداخت'});
});
app.get('/api/orders',requireAuth,(req,res)=>{
  const orders=db.prepare('SELECT id,total,status,items_json,created_at FROM orders WHERE user_id=? ORDER BY id DESC').all(req.session.userId);
  res.json({orders:orders.map(o=>({id:o.id,total:o.total,status:o.status,items:JSON.parse(o.items_json),createdAt:o.created_at}))});
});
app.get('/api/health',(req,res)=>res.json({ok:true}));
const port=Number(process.env.PORT||3000);
app.listen(port,()=>console.log(`GIFTZONE running on http://localhost:${port}`));
